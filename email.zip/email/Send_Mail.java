import java.util.Properties;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;
import jakarta.mail.Authenticator;
import jakarta.mail.BodyPart;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;

public class Send_Mail{
static String sender="meghrajyadav.yadav20@gmail.com",receiver="meghrajyadav.yadav20@gmail.com",
subject="Test Mail",message="Hello Testing Mail Success!...";
    public String mail_send(String from,String to,String subj,String msg){
        String flag="false";
        Properties prop=new Properties();
        prop.put("mail.smtp.port",587);
        prop.put("mail.smtp.host","smtp.gmail.com");
        prop.put("mail.smtp.auth","true");
        prop.put("mail.smtp.starttls.enable","true");
        String uname="meghrajyadav.yadav20";
        String pass="yoyxjhbabzhddzqb";
        Session session=Session.getInstance(prop,new Authenticator() {

            protected PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication(uname, pass);
            }
        });

        try {
            Message mssg=new MimeMessage(session);
            mssg.setFrom(new InternetAddress(from));
            mssg.setSubject(subj);
            mssg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
            mssg.setText(msg);
            
            MimeMultipart multipart = new MimeMultipart("related");
            BodyPart messageBodyPart = new MimeBodyPart();
            String htmlText = "<H1 styrle='color:red'>Hello demo mail</H1>";
            messageBodyPart.setContent(htmlText, "text/html");

            // attach file //
            multipart.addBodyPart(messageBodyPart);
            String filename = "User_Mail.java";
            messageBodyPart = new MimeBodyPart();        
            DataSource fds = new FileDataSource(filename);
            messageBodyPart.setDataHandler(new DataHandler(fds));
            messageBodyPart.setFileName(filename);
            
            multipart.addBodyPart(messageBodyPart);
            mssg.setContent(multipart);
            Transport.send(mssg);
            flag="true";
           
        } catch (Exception e) {
            System.out.println(e);
        }
        return flag;
    }
    public static void main(String[] args) {
        Send_Mail sm=new Send_Mail();
        String check=sm.mail_send(sender,receiver,subject,message);
        if(check.equals("true"))
        {
            System.out.println("Mail send Successfully!...");
        }
        else
        {
            System.out.println("Mail Failed!...");
        }
    }
}