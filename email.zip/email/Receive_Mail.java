import java.util.Properties;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;
import jakarta.mail.Authenticator;
import jakarta.mail.BodyPart;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;

public class Receive_Mail{
    static String host = "pop.gmail.com";
    static String mailStoreType = "pop3";
    static String username = "meghrajyadav.yadav20@gmail.com";
    static  String password = "yoyxjhbabzhddzqb";
  public void fetch_mail(String host_msg,String mail_type,String user,String pass){
        Properties pop=new Properties();
        pop.put("mail.pop3.host", host);
        pop.put("mail.pop3.port", "995");
        pop.put("mail.pop3.starttls.enable", "true");
        Session session=Session
        
  }
    public static void main(String[] args) {
        Receive_Mail rm=new Receive_Mail();
        rm.fetch_mail(host,mailStoreType,username,password);
    }
}